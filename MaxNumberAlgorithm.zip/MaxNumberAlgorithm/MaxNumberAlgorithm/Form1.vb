﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblInstructions.Text = "Please enter a whole number greater than 0 and less than 100, then press Enter."
        Label2.Text = ""
        Label2.Visible = False
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim datagood1 As Boolean = False
        Dim datagood2 As Boolean = False
        'Dim Number1 As Integer'
        'Dim Number2 As Integer'
        Dim message As String = ""
        checkit1(TextBox1.Text, message, datagood1)
        checkit2(TextBox2.Text, message, datagood2)
        If datagood1 = True And datagood2 = True Then
            'Number1.Textbox1.Text'
            'Number2.Textbox2.Text'
            computeit(message)
        End If
        Label2.Text = message
        Label2.Visible = True
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = MessageBox.Show("Do you really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) <> DialogResult.Yes
    End Sub


    Sub checkit1(ByVal valueA As String, ByRef message As String, ByRef valid As Boolean)
        If valueA = "" Then
            message = "Your entry is blank. Try again."
        ElseIf Not IsNumeric(valueA) Then
            message = "A number was not entered. Try again."
        ElseIf valueA - Int(valueA) <> 0 Then
            message = "An integer was not entered. Try again."
        ElseIf valueA < 0 Or valueA > 100 Then
            message = "An integer greater than 0 and less than 100 was not entered.  Try again."
        Else
            valid = True
        End If
    End Sub

    Sub checkit2(ByVal valueB As String, ByRef message As String, ByRef valid As Boolean)
        If valueB = "" Then
            message = "Your entry is blank. Try again."
        ElseIf Not IsNumeric(valueB) Then
            message = "A number was not entered. Try again."
        ElseIf valueB - Int(valueB) <> 0 Then
            message = "An integer was not entered. Try again."
        ElseIf valueB < 0 Or valueB > 100 Then
            message = "An integer greater than 0 and less than 100 was not entered.  Try again."
        Else
            valid = True
        End If
    End Sub

    Sub computeit(ByRef message As String)
        Dim maxnumber As Integer
        If (TextBox1.Text * 1) = (TextBox2.Text * 1) Then
            message = "These two values are equal to each other."
        Else
            maxnumber = Math.Max(TextBox1.Text * 1, TextBox2.Text * 1)
            message = "The maximum value is: " & maxnumber & "."
        End If
    End Sub

End Class
