﻿Public Class Form1


    Public Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim filingstatus(2, 1)
        filingstatus(0, 0) = "Single"
        filingstatus(0, 1) = 12200
        filingstatus(1, 0) = "Married Filing Jointly"
        filingstatus(1, 1) = 24400
        filingstatus(2, 0) = "Head of Household"
        filingstatus(2, 1) = 18350

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    End Sub


End Class
