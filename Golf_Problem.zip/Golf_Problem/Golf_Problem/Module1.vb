﻿Module Module1

    Public Sub checkit(ByVal valueA As String, ByRef message As String, ByRef valid As Boolean)
        If valueA = "" Then
            message = "Your entry is blank. Try again."
        ElseIf Not IsNumeric(valueA) Then
            message = "A number was not entered. Try again."
        ElseIf valueA - Int(valueA) <> 0 Then
            message = "An integer was not entered. Try again."
        ElseIf valueA < 78 Or valueA > 100 Then
            message = "An integer greater than 78 and less than 100" & vbNewLine & "was not entered.  Try again."
        Else
            valid = True
        End If
    End Sub
End Module
