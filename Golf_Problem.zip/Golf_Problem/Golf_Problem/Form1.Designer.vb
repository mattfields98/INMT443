﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.UsernameBox = New System.Windows.Forms.TextBox()
        Me.Entry3 = New System.Windows.Forms.TextBox()
        Me.Entry4 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Entry1 = New System.Windows.Forms.TextBox()
        Me.Entry5 = New System.Windows.Forms.TextBox()
        Me.Entry2 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ClearBtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'UsernameBox
        '
        Me.UsernameBox.Location = New System.Drawing.Point(142, 102)
        Me.UsernameBox.Name = "UsernameBox"
        Me.UsernameBox.Size = New System.Drawing.Size(155, 29)
        Me.UsernameBox.TabIndex = 0
        '
        'Entry3
        '
        Me.Entry3.Location = New System.Drawing.Point(279, 272)
        Me.Entry3.Name = "Entry3"
        Me.Entry3.Size = New System.Drawing.Size(57, 29)
        Me.Entry3.TabIndex = 1
        '
        'Entry4
        '
        Me.Entry4.Location = New System.Drawing.Point(85, 332)
        Me.Entry4.Name = "Entry4"
        Me.Entry4.Size = New System.Drawing.Size(57, 29)
        Me.Entry4.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(109, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 25)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(71, 206)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 25)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Label2"
        '
        'Entry1
        '
        Me.Entry1.Location = New System.Drawing.Point(85, 272)
        Me.Entry1.Name = "Entry1"
        Me.Entry1.Size = New System.Drawing.Size(57, 29)
        Me.Entry1.TabIndex = 5
        '
        'Entry5
        '
        Me.Entry5.Location = New System.Drawing.Point(279, 332)
        Me.Entry5.Name = "Entry5"
        Me.Entry5.Size = New System.Drawing.Size(57, 29)
        Me.Entry5.TabIndex = 6
        '
        'Entry2
        '
        Me.Entry2.Location = New System.Drawing.Point(183, 272)
        Me.Entry2.Name = "Entry2"
        Me.Entry2.Size = New System.Drawing.Size(57, 29)
        Me.Entry2.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(85, 432)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(190, 55)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Enter"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(358, 432)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(187, 55)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Exit"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(376, 272)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 25)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Label3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(314, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 25)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Label4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(410, 177)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 25)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Label5"
        '
        'ClearBtn
        '
        Me.ClearBtn.Location = New System.Drawing.Point(215, 520)
        Me.ClearBtn.Name = "ClearBtn"
        Me.ClearBtn.Size = New System.Drawing.Size(232, 45)
        Me.ClearBtn.TabIndex = 13
        Me.ClearBtn.Text = "Clear"
        Me.ClearBtn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1119, 607)
        Me.Controls.Add(Me.ClearBtn)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Entry2)
        Me.Controls.Add(Me.Entry5)
        Me.Controls.Add(Me.Entry1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Entry4)
        Me.Controls.Add(Me.Entry3)
        Me.Controls.Add(Me.UsernameBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents UsernameBox As System.Windows.Forms.TextBox
    Friend WithEvents Entry3 As System.Windows.Forms.TextBox
    Friend WithEvents Entry4 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Entry1 As System.Windows.Forms.TextBox
    Friend WithEvents Entry5 As System.Windows.Forms.TextBox
    Friend WithEvents Entry2 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ClearBtn As System.Windows.Forms.Button

End Class
