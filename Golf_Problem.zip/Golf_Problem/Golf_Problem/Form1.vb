﻿Public Class Form1
    Dim golfscores(4)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Please enter your name"
        Label2.Text = "Please enter your golf scores" & vbNewLine & "ranging from 78 to 100"
        Label3.Text = ""
        Label3.Visible = False
        Label4.Text = ""
        Label4.Visible = False
        Label5.Visible = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim datagood1 As Boolean = False
        Dim datagood2 As Boolean = False
        Dim datagood3 As Boolean = False
        Dim datagood4 As Boolean = False
        Dim datagood5 As Boolean = False
        Dim usernamegood As Boolean = False
        Dim message1 As String = ""
        Dim message2 As String = ""
        checkusername(UsernameBox.Text, message1, usernamegood)
        checkit(Entry1.Text, message2, datagood1)
        checkit(Entry2.Text, message2, datagood2)
        checkit(Entry3.Text, message2, datagood3)
        checkit(Entry4.Text, message2, datagood4)
        checkit(Entry5.Text, message2, datagood5)
        If usernamegood And datagood1 And datagood2 And datagood3 And datagood4 And datagood5 Then
            Call LoadScores()
            Dim golfhandicap As Double
            Call ComputeHandicap(golfhandicap)
            Dim GolferType As String = ""
            Call ComputeGolferType(golfhandicap, GolferType)
            Label5.Visible = True
            Label5.Text = UsernameBox.Text & ", your handicap qualifies you as a(n) " & GolferType & " golfer."
        End If
        Label3.Text = message2
        Label3.Visible = True
        Label4.Text = message1
        Label4.Visible = True
    End Sub


    Sub checkusername(ByVal username As String, ByRef message As String, ByRef valid As Boolean)
        If username = "" Then
            message = "Your name is blank. Try again."
        ElseIf IsNumeric(username) Then
            message = "A name was not entered correctly. Try again"
        Else : valid = True
        End If
    End Sub

    Sub ComputeHandicap(ByRef golfhandicap As Double)
        Dim SumOfScores, TopFour, AverageScore As Double
        For i = 0 To 4
            SumOfScores = SumOfScores + golfscores(i)
        Next
        TopFour = SumOfScores - golfscores.Min()
        AverageScore = (TopFour / 4)
        golfhandicap = Math.Round(AverageScore - 72) * 0.9
    End Sub

    Sub ComputeGolferType(ByVal golfhandicap As Double, ByRef GolferType As String)
        If golfhandicap > 18 Then
            GolferType = "poor"
        ElseIf golfhandicap >= 8 Then
            GolferType = "average"
        Else : GolferType = "good"
        End If
    End Sub

    Sub LoadScores()
        golfscores(0) = Entry1.Text
        golfscores(1) = Entry2.Text
        golfscores(2) = Entry3.Text
        golfscores(3) = Entry4.Text
        golfscores(4) = Entry5.Text
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = MessageBox.Show("Do you really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) <> DialogResult.Yes
    End Sub

    Private Sub ClearBtn_Click(sender As Object, e As EventArgs) Handles ClearBtn.Click
        Dim cControl As Control
        For Each cControl In Me.Controls
            If TypeName(cControl) = "TextBox" Then
                cControl.Text = ""
            End If
        Next cControl
        For Each cControl In Me.Controls
            If TypeName(cControl) = "Label" Then
                cControl.Text = ""
            End If
        Next cControl
        Label1.Text = "Please enter your name"
        Label2.Text = "Please enter your golf scores" & vbNewLine & "ranging from 78 to 100"
    End Sub

End Class
