﻿Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If UsernameBox.Text = "username" And PasswordBox.Text = "password" Then
            Form1.ShowDialog()
        Else : MsgBox("Sorry, The Username And/Or Password was Incorrect.", MsgBoxStyle.Critical, "Information")
        End If
    End Sub
    Private Sub Login_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = MessageBox.Show("Do you really want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) <> DialogResult.Yes
    End Sub
End Class